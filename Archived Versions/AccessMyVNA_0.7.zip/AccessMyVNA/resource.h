//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by AccessMyVNA.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_ACCESSMYVNA_DIALOG          102
#define IDS_CALL_ERROR                  102
#define IDR_MAINFRAME                   128
#define IDC_BUTTON_INIT                 1000
#define IDC_BUTTON1                     1001
#define IDC_EDIT_SCANPOINTS             1002
#define IDC_BUTTON_SETSCANPOINTS        1003
#define IDC_BUTTON_GETSCANPOINTS        1004
#define IDC_EDIT_SCANAVG                1005
#define IDC_BUTTON_SETSCANAVG           1006
#define IDC_BUTTON_GETSCANAVG           1007
#define IDC_EDIT_FSTART                 1008
#define IDC_EDIT_FSTOP                  1009
#define IDC_BUTTON_SETFREQ              1010
#define IDC_BUTTON_GETFREQ              1011
#define IDC_BUTTON2                     1012
#define IDC_BUTTON3                     1013
#define IDC_BUTTON_SETINSTRMODE         1014
#define IDC_BUTTON4                     1015
#define IDC_RICHEDIT21                  1016
#define IDC_STATIC_SCANSTATUS           1017
#define IDC_COMBO_PARAMETER_TYPE        1018
#define IDC_CHECK1                      1019
#define IDC_EDIT_INSTRUMENTMODE         1020
#define IDC_BUTTON_GETINSTRMODE         1021
#define IDC_BUTTON_SAVECONFIG           1022
#define IDC_BUTTON_LOADCONFIG           1023
#define IDC_BUTTON_LOADCALIB            1024
#define IDC_BUTTON_SAVECALIB            1025
#define IDC_COMBO_OTHERS                1026
#define IDC_EDIT_OTHER1                 1027
#define IDC_BUTTON_AUTOSCALE            1028
#define IDC_BUTTON_SETOTHERS            1029
#define IDC_BUTTON_GETOTHERS            1030
#define IDC_EDIT_OTHER2                 1031
#define IDC_EDIT_OTHER3                 1032
#define IDC_EDIT_OTHER4                 1033
#define IDC_BUTTON_CLIPBOARD_COPY       1034
#define IDC_BUTTON_SAVESCAN             1035
#define IDC_EDIT_DISPLAYMODE            1036
#define IDC_BUTTON_DISPLAYMODE          1037
#define IDC_BUTTON_GETDISPLAYMODE       1038
#define IDC_EDIT_OTHER5                 1039
#define IDC_EDIT_OTHER6                 1040
#define IDC_EDIT_RETVALUE               1041
#define IDC_EDIT_INDEXVALUE             1042
#define IDC_BUTTON_REFINE               1043
#define IDC_BUTTON_REFINE_CHOOSE_LOG    1044
#define IDC_BUTTON_REFINE_LOG           1045
#define IDC_BUTTON_GET_EQ_CCT_DATA      1046
#define IDC_STATIC_FORMAT               1047
#define IDC_EDIT_INDEXVALUE2            1048
#define IDC_BUTTON_SETSTRING            1049
#define IDC_BUTTON_GETSTRING            1050
#define IDC_COMBO_STRING_OTHERS         1051
#define IDC_EDIT_STRINGS                1052
#define IDC_EDIT_RETVALUE2              1053

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1053
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
