// stdafx.cpp : source file that includes just the standard includes
// AccessMyVNA.pch will be the pre-compiled header
// stdafx.obj will contain the pre-compiled type information

#include "stdafx.h"


